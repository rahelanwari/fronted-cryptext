crypText
├── backend
│   ├── src
│   │   ├── controllers
│   │   │   └── __init__.py
│   │   ├── models
│   │   │   └── __init__.py
│   │   ├── routes
│   │   │   ├── __init__.py
│   │   │   └── api.py
│   │   └── utils
│   │       └── __init__.py
│   ├── app.py
│   ├── config.py
│   └── requirements.txt
└── README.md